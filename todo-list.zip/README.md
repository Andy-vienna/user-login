Small ToDo-List App with just basic functions for personal belongings
